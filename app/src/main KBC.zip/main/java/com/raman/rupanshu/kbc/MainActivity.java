package com.raman.rupanshu.kbc;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.crashlytics.android.Crashlytics;

import io.fabric.sdk.android.Fabric;

public class MainActivity extends Activity {

    Animation A;
    MediaPlayer mMediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Next three lines for Full Screen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fabric.with(this, new Crashlytics());
        //set volume key control
        this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
        mMediaPlayer = MediaPlayer.create(this, R.raw.kbc_start_soundtrack);
        mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mMediaPlayer.setLooping(false);
        mMediaPlayer.setVolume(0.3f, 0.3f);
        mMediaPlayer.start();
        mMediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                Log.d("MA", "mp released");
                mediaPlayer.release();
            }
        });
        //for rating count visits
        ImageView kbc = (ImageView) findViewById(R.id.kbc);
        A = AnimationUtils.loadAnimation(this, R.anim.animation_button_play);
        kbc.startAnimation(A);
        Thread timerThread = new Thread() {

            public void run() {             /* change time of sleep when changing alpha animation of kbc icon */
                try {
                    int i = 0;
                    while (i <= 1) {
                        sleep(1000);
                        i++;
                    }

                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    Intent intent = new Intent(MainActivity.this, output.class);
                    startActivity(intent);
                    finish();
                }
            }
        };
        timerThread.start();
    }
}